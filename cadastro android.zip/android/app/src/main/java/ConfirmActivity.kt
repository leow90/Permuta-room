package com.example.cadastroandroid

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.cadastroandroid.ui.theme.CadastroAndroidTheme

class ConfirmActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("CicloDeVida", "ConfirmActivity -> onCreate()")

        val nome = intent.getStringExtra("NOME") ?: ""
        val idade = intent.getStringExtra("IDADE") ?: ""
        val endereco = intent.getStringExtra("ENDERECO") ?: ""

        setContent {
            CadastroAndroidTheme {
                TelaConfirmacao(
                    nome = nome,
                    idade = idade,
                    endereco = endereco,
                    onConfirmar = {
                        Toast.makeText(this, "Cadastro salvo com sucesso!", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this, MainActivity::class.java))
                        finish()
                    },
                    onEditar = {
                        val intent = Intent(this, MainActivity::class.java).apply {
                            putExtra("NOME", nome)
                            putExtra("IDADE", idade)
                            putExtra("ENDERECO", endereco)
                        }
                        startActivity(intent)
                        finish()
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TelaConfirmacao(nome: String, idade: String, endereco: String, onConfirmar: () -> Unit, onEditar: () -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Confirmação") }) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("Nome: $nome")
            Text("Idade: $idade")
            Text("Endereço: $endereco")
            Spacer(modifier = Modifier.height(16.dp))
            Text("Seus dados estão corretos?")
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Button(onClick = onConfirmar) { Text("Sim") }
                Button(onClick = onEditar) { Text("Não") }
            }
        }
    }
}
