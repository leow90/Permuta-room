package com.example.cadastroandroid

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.cadastroandroid.ui.theme.CadastroAndroidTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("CicloDeVida", "MainActivity -> onCreate()")

        setContent {
            CadastroAndroidTheme {
                TelaCadastro { nome, idade, endereco ->
                    val intent = Intent(this, ConfirmActivity::class.java).apply {
                        putExtra("NOME", nome)
                        putExtra("IDADE", idade)
                        putExtra("ENDERECO", endereco)
                    }
                    startActivity(intent)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TelaCadastro(onSalvarClick: (String, String, String) -> Unit) {
    var nome by remember { mutableStateOf("") }
    var idade by remember { mutableStateOf("") }
    var endereco by remember { mutableStateOf("") }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Cadastro") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            OutlinedTextField(value = nome, onValueChange = { nome = it }, label = { Text("Nome") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = idade, onValueChange = { idade = it }, label = { Text("Idade") }, keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = endereco, onValueChange = { endereco = it }, label = { Text("Endereço") }, modifier = Modifier.fillMaxWidth())

            Spacer(modifier = Modifier.height(16.dp))

            Button(onClick = { onSalvarClick(nome, idade, endereco) }, modifier = Modifier.fillMaxWidth()) {
                Text("Salvar")
            }
        }
    }
}
