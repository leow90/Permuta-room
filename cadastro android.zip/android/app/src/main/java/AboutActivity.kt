package com.example.cadastroandroid

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.cadastroandroid.ui.theme.CadastroAndroidTheme

class AboutActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CadastroAndroidTheme {
                TelaSobre()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TelaSobre() {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Sobre") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text("Aplicativo desenvolvido por:")
            Text("Leonardo Estevao Alves 1 - RA 00250458-1")
            Text("Nome 2 - RA 654321")
            Text("Nome 3 - RA 789012")
            Spacer(modifier = Modifier.height(16.dp))
            Text("Curso: Sistema de informaçao")
            Text("Professor: Carlos Eduardo Simao Pelegrin ")
            Text("Faculdade: Unipar ")
        }
    }
}
