@file:Suppress("UnusedImport")

package com.example.pessoas.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PessoaDao {

    @Query("SELECT * FROM pessoa ORDER BY nome ASC")
    fun getAll(): Flow<List<Pessoa>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(pessoa: Pessoa)

    @Delete
    suspend fun delete(pessoa: Pessoa)

    annotation class Delete
}
