package com.example.roompeople.pessoas

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// Modelo de dados
data class Pessoa(val id: Int, val nome: String, val idade: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PessoasApp()
        }
    }
}

enum class Screen {
    Splash, Menu, Lista, Detalhes
}

@SuppressLint("MutableCollectionMutableState")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PessoasApp() {
    var screenState by remember { mutableStateOf(Screen.Splash) }
    var pessoas by remember {
        mutableStateOf(
            mutableListOf(
                Pessoa(1, "Leonardo", 20),
                Pessoa(2, "Maria", 25),
                Pessoa(3, "João", 40),
                Pessoa(4, "Ana", 22),
            )
        )
    }
    var selectedPessoa by remember { mutableStateOf<Pessoa?>(null) }

    when (screenState) {
        Screen.Splash -> SplashScreen {
            screenState = Screen.Menu
        }
        Screen.Menu -> MenuScreen(
            onShowPessoas = { screenState = Screen.Lista },
        )
        Screen.Lista -> ListaPessoasScreen(
            pessoas = pessoas,
            onPessoaClick = {
                selectedPessoa = it
                screenState = Screen.Detalhes
            },
            onAddPessoa = { nome, idade ->
                val novoId = (pessoas.maxOfOrNull { p -> p.id } ?: 0) + 1
                pessoas = (pessoas + Pessoa(novoId, nome, idade)).toMutableList()
            },
            onBack = {
                screenState = Screen.Menu
            }
        )
        Screen.Detalhes -> selectedPessoa?.let { pessoa ->
            PessoaDetalhesScreen(
                pessoa = pessoa,
                onBack = { screenState = Screen.Lista },
                onDelete = {
                    pessoas = pessoas.filter { it.id != pessoa.id }.toMutableList()
                    screenState = Screen.Lista
                }
            )
        }
    }
}

@Composable
fun SplashScreen(onTimeout: () -> Unit) {
    var startAnimation by remember { mutableStateOf(false) }
    val alphaAnim by animateFloatAsState(if (startAnimation) 1f else 0f)

    LaunchedEffect(Unit) {
        startAnimation = true
        delay(2500)
        onTimeout()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .alpha(alphaAnim),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "PESSOAS",
            style = MaterialTheme.typography.displayLarge.copy(fontSize = 48.sp),
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuScreen(onShowPessoas: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Menu Principal") }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.Center
        ) {
            Button(onClick = onShowPessoas) {
                Text("Pessoas")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListaPessoasScreen(
    pessoas: List<Pessoa>,
    onPessoaClick: (Pessoa) -> Unit,
    onAddPessoa: (String, Int) -> Unit,
    onBack: () -> Unit
) {
    var nomeInput by remember { mutableStateOf(TextFieldValue("")) }
    var idadeInput by remember { mutableStateOf(TextFieldValue("")) }
    val idadeInt = idadeInput.text.toIntOrNull() ?: 0

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Lista de Pessoas") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(8.dp)
        ) {

            LazyColumn(modifier = Modifier.weight(1f)) {
                items(pessoas) { pessoa ->
                    PessoaCard(pessoa = pessoa, onClick = { onPessoaClick(pessoa) })
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("Adicionar Pessoa", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = nomeInput,
                onValueChange = { nomeInput = it },
                label = { Text("Nome") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = idadeInput,
                onValueChange = { idadeInput = it },
                label = { Text("Idade") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = idadeInput.text.isNotEmpty() && idadeInt <= 0
            )
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = {
                    if (nomeInput.text.isNotBlank() && idadeInt > 0) {
                        onAddPessoa(nomeInput.text.trim(), idadeInt)
                        nomeInput = TextFieldValue("")
                        idadeInput = TextFieldValue("")
                    }
                },
                enabled = nomeInput.text.isNotBlank() && idadeInt > 0,
                modifier = Modifier.align(Alignment.End)
            ) {
                Text("Adicionar")
            }
        }
    }
}

@Composable
fun PessoaCard(pessoa: Pessoa, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = pessoa.nome, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Idade: ${pessoa.idade}", style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PessoaDetalhesScreen(
    pessoa: Pessoa,
    onBack: () -> Unit,
    onDelete: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Detalhes de ${pessoa.nome}") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text("Nome: ${pessoa.nome}", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Idade: ${pessoa.idade}", style = MaterialTheme.typography.headlineSmall)
            Spacer(modifier = Modifier.height(32.dp))
            Button(
                onClick = onDelete,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) {
                Text("Remover Pessoa", color = MaterialTheme.colorScheme.onError)
            }
        }
    }
}
