package com.example.pessoas.data

import kotlinx.coroutines.flow.Flow

class PessoaRepository(private val dao: PessoaDao) {
    fun getAllPessoas(): Flow<List<Pessoa>> = dao.getAll()

    suspend fun insertPessoa(pessoa: Pessoa) = dao.insert(pessoa)

    suspend fun deletePessoa(pessoa: Pessoa) = dao.delete(pessoa)
}
